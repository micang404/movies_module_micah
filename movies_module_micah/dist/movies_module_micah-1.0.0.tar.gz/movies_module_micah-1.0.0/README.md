# movies_module_micah Package

This is an exercise module that provides
a function called print_lol() that prints
lists that may or may not contain nested lists.

This function takes a positional argument
called 'the_list', which can be any Python
list (or a list containing nested lists).
Each item in the specified list is
(recursively) printed to the screen,
 one row each.